#!/usr/bin/env python3

import logging
import platform
import subprocess
import sys
import aiy.assistant.auth_helpers
from aiy.assistant.library import Assistant
import aiy.audio
import aiy.voicehat
from google.assistant.library.event import EventType
#import aiy.voicehat
import os, random

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s:%(name)s:%(message)s"
)

import RPi.GPIO as GPIO
import GPIO_EX
from time import sleep
import aiy.device._textlcd as TLCD
import aiy.device._adc as ADC
import aiy.device._led as LED
import aiy.device._buzzer as BUZZER
import aiy.device._pir as PIR
import aiy.device._keypad as KEYPAD
import aiy.device._dht11 as DHT
import aiy.device._fan as FAN
import threading

detect_state = 0
auto_light_system_status = 0
auto_security_system_status = 0

led_status = 0
buzzer_status = 0
g_counter = 0

inputPasswd = []
passwd = ['2','5','8','0']

melodyList      = [7]
noteDurations   = [0.5]

openDoorBeep = [2,0,4,7]
noteDurations1 = [1,1,1,1]

errorBeep = [1,1]
noteDurations2 = [1,2]

auto_fire_system_status = 0
flag_system_status = 0

auto_air_system_status = 0

def airSystem():
    global auto_air_system_status
    while True:
#        print("status = %d "%auto_air_system_status)
        if auto_air_system_status == True:
            tempVal = DHT.readTemp()
            TLCD.controlLine(0)
            TLCD.displayText(str(tempVal))
            if (tempVal > 24):
                print("TEMP = %0.1f [C] "%tempVal)
                FAN.controlFan(FAN.ON)
            else:
                FAN.controlFan(FAN.OFF)
        else:
            TLCD.clearTextlcd()
            return 0

def fireSystem():
    global auto_fire_system_status
    while True:
        if auto_fire_system_status == True:
            gasVal = ADC.readSensor(ADC.GAS_CHANNEL)
            if (gasVal > 200):
                print("GAS Value = %d "%gasVal)
#                BUZZER.playBuzzer(melodyList, noteDurations)
#                sleep(0.5)
#            else:
#                sleep(0.5)
#                BUZZER.pwm.stop()
        else:
            return 0

def verifyPasswd():
    if passwd == inputPasswd:
        print("passwd correct!!")
        return 0
    else:
        return -1

def inputText(keyData):
    global g_counter

    if keyData == 0:
        inputPasswd.append('0')
        g_counter += 1
    elif keyData == 1:
        inputPasswd.append('1')
        g_counter += 1
    elif keyData == 2:
        inputPasswd.append('2')
        g_counter += 1
    elif keyData == 3:
        inputPasswd.append('3')
        g_counter += 1
    elif keyData == 4:
        inputPasswd.append('4')
        g_counter += 1
    elif keyData == 5:
        inputPasswd.append('5')
        g_counter += 1
    elif keyData == 6:
        inputPasswd.append('6')
        g_counter += 1
    elif keyData == 7:
        inputPasswd.append('7')
        g_counter += 1
    elif keyData == 8:
        inputPasswd.append('8')
        g_counter += 1
    elif keyData == 9:
        inputPasswd.append('9')
        g_counter += 1

def doorSystem():
    global g_counter
    global inputPasswd
    while True:
        keyData = KEYPAD.readKeypad()
        inputText(keyData)

        if g_counter == 4:
            print("passwd : %s"%inputPasswd)
            if verifyPasswd() == 0:
#                BUZZER.playBuzzer(openDoorBeep, noteDurations1)
#                sleep(0.5)
#                BUZZER.pwm.stop()
                print("door is opened!!")
            else:
                print("wrong passward!!")
#                BUZZER.playBuzzer(errorBeep, noteDurations2)
#                sleep(0.5)
#                BUZZER.pwm.stop()
            
            g_counter = 0
            del inputPasswd[0:4]

def buzzerSystem():
    global buzzer_status
    while True:
        if buzzer_status == True:
            BUZZER.playBuzzer(melodyList, noteDurations)
            sleep(0.5)
        else:
            sleep(0.5)
            BUZZER.pwm.stop()
            return 0

def securitySystem():
    global auto_security_system_status
    while True:
        if auto_security_system_status == True:
            motionVal = PIR.readPir(PIR.ON)
#            print("motion = %d "%motionVal)
            if motionVal == True:
                print("motion = %d "%motionVal)
                BUZZER.playBuzzer(melodyList, noteDurations)
                sleep(0.5)
            else:
                sleep(0.5)
                BUZZER.pwm.stop()
        else:
            return 0

def lightSystem(detect_state):
    global auto_light_system_status
    global led_status
    while detect_state:
        if auto_light_system_status == True:
            cdsVal = ADC.readSensor(ADC.CDS_CHANNEL)
#            TLCD.controlLine(1)
#            TLCD.displayText(str(cdsVal))
#            print("illuminance = %d "%cdsVal)
                
            if ( cdsVal<100 and led_status==0 ):
                print("illuminance = %d "%cdsVal)
                LED.controlLed(LED.LED_1, LED.ON)
                sleep(0.1)
                LED.controlLed(LED.LED_2, LED.ON)
                sleep(0.1)
                LED.controlLed(LED.LED_3, LED.ON)
                sleep(0.1)
                LED.controlLed(LED.LED_4, LED.ON)
                led_status = 1
            elif ( cdsVal>=100 and led_status==1 ):
                LED.controlLed(LED.LED_1, LED.OFF)
                sleep(0.1)
                LED.controlLed(LED.LED_2, LED.OFF)
                sleep(0.1)
                LED.controlLed(LED.LED_3, LED.OFF)
                sleep(0.1)
                LED.controlLed(LED.LED_4, LED.OFF)
                led_status = 0
        else:
            TLCD.clearTextlcd()
            return 0

def process_event(assistant, event):
    global detect_state
    global led_status
    global buzzer_status
    global t_security
    global t1
    global t
    global auto_light_system_status
    global auto_security_system_status
    global t_fire
    global auto_fire_system_status
    global flag_system_status
    global t_air
    global auto_air_system_status
    status_ui = aiy.voicehat.get_status_ui()
#    print("status_ui : %s"%status_ui)
    if event.type == EventType.ON_START_FINISHED:
        status_ui.status('ready')
        if sys.stdout.isatty():
            print('Say "OK, Google" then speak, or press Ctrl+C to quit...')

    elif event.type == EventType.ON_CONVERSATION_TURN_STARTED:
        status_ui.status('listening')
        print("Yes, I'm listening...")

    elif event.type == EventType.ON_RECOGNIZING_SPEECH_FINISHED and event.args:
        print('You said:', event.args['text'])
        text = event.args['text'].lower()
        if text == 'ready system':
            assistant.stop_conversation()
            aiy.audio.say('ready light control system')
            detect_state = True
            auto_light_system_status = True
            t = threading.Thread(target=lightSystem, args=(detect_state, ))
            t.daemon = True
            t.start()

            auto_security_system_status = True
            buzzer_status = False
            t_security = threading.Thread(target=securitySystem, args=( ))
            t_security.daemon = True
            t_security.start()

            auto_fire_system_status = True
            t_fire = threading.Thread(target=fireSystem, args=( ))
            t_fire.daemon = True
            t_fire.start()

            auto_air_system_status = True
            t_air = threading.Thread(target=airSystem, args=( ))
            t_air.daemon = True
            t_air.start()

        if text == 'system on':
            auto_light_system_status = False
            assistant.stop_conversation()
            aiy.audio.say('system start')
            LED.controlLed(LED.LED_1, LED.ON)
            sleep(0.1)
            LED.controlLed(LED.LED_2, LED.ON)
            sleep(0.1)
            LED.controlLed(LED.LED_3, LED.ON)
            sleep(0.1)
            LED.controlLed(LED.LED_4, LED.ON)
            led_status = 1
        if text == 'system off':
            auto_light_system_status = False
            assistant.stop_conversation()
            aiy.audio.say('system off')
            LED.controlLed(LED.LED_1, LED.OFF)
            sleep(0.1)
            LED.controlLed(LED.LED_2, LED.OFF)
            sleep(0.1)
            LED.controlLed(LED.LED_3, LED.OFF)
            sleep(0.1)
            LED.controlLed(LED.LED_4, LED.OFF)
            led_status = 0
        if text == 'ready door system':
            auto_security_system_status = False 
            assistant.stop_conversation()
            aiy.audio.say('ready door system')
            t1 = threading.Thread(target=doorSystem, args=( ))
            t1.daemon = True
            t1.start()


    elif event.type == EventType.ON_END_OF_UTTERANCE:
        status_ui.status('thinking')

    elif (event.type == EventType.ON_CONVERSATION_TURN_FINISHED
          or event.type == EventType.ON_CONVERSATION_TURN_TIMEOUT
          or event.type == EventType.ON_NO_RESPONSE):
        status_ui.status('ready')

    elif event.type == EventType.ON_ASSISTANT_ERROR and event.args and event.args['is_fatal']:
        sys.exit(1)


def main():
    if platform.machine() == 'armv6l':              # Returns the machine type, e.g. 'i386'.
        print('Cannot run hotword demo on Pi Zero!')
        exit(-1)
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    ADC.initMcp3208()

    LED.initLed(LED.LED_1)
    LED.initLed(LED.LED_2)
    LED.initLed(LED.LED_3)
    LED.initLed(LED.LED_4)
    TLCD.initTextlcd()

    GPIO.setup(BUZZER.BUZZER_PIN, GPIO.OUT)
    pwm = GPIO.PWM(BUZZER.BUZZER_PIN, 100)

    GPIO_EX.setup(PIR.PIR_PIN, GPIO_EX.IN)

    KEYPAD.initKeypad()

    GPIO.setup(DHT.DHT_PIN, GPIO.IN)

    FAN.initFan(FAN.FAN_PIN1,FAN.FAN_PIN2)


    credentials = aiy.assistant.auth_helpers.get_assistant_credentials()
    with Assistant(credentials) as assistant:
        for event in assistant.start():
            process_event(assistant, event)

if __name__ == '__main__':
    main()

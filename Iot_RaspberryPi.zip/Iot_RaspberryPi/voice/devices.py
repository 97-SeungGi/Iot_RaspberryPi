#!/usr/bin/env python3

import logging
import platform
import subprocess
import sys
import aiy.assistant.auth_helpers
from aiy.assistant.library import Assistant
import aiy.audio
import aiy.voicehat
from google.assistant.library.event import EventType
import os, random

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s:%(name)s:%(message)s"
)

import RPi.GPIO as GPIO
from time import sleep
import aiy.device._led as LED
import aiy.device._fan as FAN
import aiy.device.motor as MOTOR
import aiy.device._buzzer as BUZZER
import aiy.device._textlcd as TLCD
#import aiy.device.fnd as FND
#import aiy.device.temp_humi as SHT
import aiy.device._dht11 as DHT
#import aiy.device.ultrasonic as ULTRA
import aiy.device._cds as CDS
import aiy.device.soil as SOIL
import aiy.device.psd as PSD

melodyList = [4,4,5,5,4,4,2,4,4,2,2,1,4,4,5,5,4,4,2,4,2,1,2,0]
noteDurations = [0.5,0.5,0.5,0.5,0.5,0.5,1,0.5,0.5,0.5,0.5,1,
                 0.5,0.5,0.5,0.5,0.5,0.5,1,0.5,0.5,0.5,0.5,1]

def power_off_pi():
    aiy.audio.say('Good bye!')
    subprocess.call('sudo shutdown now', shell=True)

def reboot_pi():
    aiy.audio.say('See you in a bit!')
    subprocess.call('sudo reboot', shell=True)

def say_ip():
    ip_address = subprocess.check_output("hostname -I | cut -d' ' -f1", shell=True)
    aiy.audio.say('My IP address is %s' % ip_address.decode('utf-8'))

def playMusic():
    aiy.audio.say('Play Music')
    randomfile = random.choice(os.listdir("/home/pi/Music/"))
    file = '/home/pi/Music/'+ randomfile
    os.system ('omxplayer ' + file)
#   subprocess.call('omxplayer *.mp3', shell=True)

def isNumber(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def literalToNumber(s):
    try:
        return FND.literalNumberTable.index(s)
    except ValueError:
        print('The command is wrong.')

def process_event(assistant, event):
    status_ui = aiy.voicehat.get_status_ui()
#    print("status_ui : %s"%status_ui)
    if event.type == EventType.ON_START_FINISHED:
        status_ui.status('ready')
        if sys.stdout.isatty():
            print('Say "OK, Google" then speak, or press Ctrl+C to quit...')

    elif event.type == EventType.ON_CONVERSATION_TURN_STARTED:
        status_ui.status('listening')
        print("Yes, I'm listening...")

    elif event.type == EventType.ON_RECOGNIZING_SPEECH_FINISHED and event.args:
        print('You said:', event.args['text'])
        text = event.args['text'].lower()
#        for i in range(0, len(event.args['text'])):        
#            print(i, text[i])

# LED
        if text == 'led on':
            assistant.stop_conversation()
            aiy.audio.say('led on')
            LED.controlLed(LED.LED_1, LED.ON)
        elif text == 'led off':
            assistant.stop_conversation()
            aiy.audio.say('led off')
            LED.controlLed(LED.LED_1, LED.OFF)
# FAN
        if text == 'start fan':
            assistant.stop_conversation()
            aiy.audio.say('start fan')
            FAN.controlFan(FAN.ON)
        elif text == 'stop fan':
            assistant.stop_conversation()
            aiy.audio.say('stop fan')
            FAN.controlFan(FAN.OFF)
# BUZZER
        if text == 'start sound':
            assistant.stop_conversation()
            aiy.audio.say('start buzzer')
            BUZZER.playBuzzer(melodyList, noteDurations)
# TLCD 
        command_display = text[:7]
        data = text[8:]

        if command_display == 'display':
            assistant.stop_conversation()
            aiy.audio.say('display text to lcd')
            TLCD.displayText(data)
        elif text == 'turn lcd off':
            assistant.stop_conversation()
            aiy.audio.say('turn lcd off')
            TLCD.initTextlcd()
# FND
        if command_display == 'display':
            if (isNumber(text[8:9])):
                number = int(text[8:9])
                print(number)
            else:
                number = literalToNumber(text[8:])
            assistant.stop_conversation()
            aiy.audio.say('display fnd')
            FND.displayFnd(1, number)
        elif text == 'turn fnd off':
            assistant.stop_conversation()
            aiy.audio.say('turn fnd off')
            FND.initFnd()
# SHT 
        if text == 'show temperature':
            assistant.stop_conversation()
            aiy.audio.say('show temperature')
            temp = SHT.read_temperature(SHT._command, SHT.ack)
            print("Temp = %2.2f [C]"%temp)
        elif text == 'show humidity':
            assistant.stop_conversation()
            aiy.audio.say('show humidity')
            humi = SHT.read_humidity(SHT._command, SHT.ack)
            print("Humi = %2.2f [%%]"%humi)
# ULTRASONIC
        if text == 'show distance':
            assistant.stop_conversation()
            aiy.audio.say('show distance')
            distance = ULTRA.controlUltrasonic()
            print("Distance = %d [cm]"%distance)
# MOTOR
        command = text[:11]
        direction = text[16:]
        if (isNumber(text[12:14])):
            speed = float(text[12:14])
            print(speed)
        else:
            speed = 0.0

        if command == 'start motor':        # start motor 20% clockwise
            if (speed>10 and speed<100):
                if (direction == 'counterclockwise'):
                    assistant.stop_conversation()
                    aiy.audio.say('start motor')
                    MOTOR.stopMotor()
                    sleep(3.0)
                    MOTOR.controlMotor(speed, MOTOR.CCW)
                elif (direction == 'clockwise'):
                    assistant.stop_conversation()
                    aiy.audio.say('start motor')
                    MOTOR.stopMotor()
                    sleep(3.0)
                    MOTOR.controlMotor(float(speed), MOTOR.CW)
        elif command == 'stop motor':
            assistant.stop_conversation()
            aiy.audio.say('stop motor')
            MOTOR.stopMotor()
            sleep(5.0)
# CDS 
        if text == 'show illuminance':
            assistant.stop_conversation()
            aiy.audio.say('show illuminance')
            cdsVal = CDS.readCdsSensor(CDS.CDS_CHANNEL)
            print("illuminance Value = %d "%cdsVal)
# SOIL 
        if text == 'show soil moisture':
            assistant.stop_conversation()
            aiy.audio.say('show soil moisture')
            soilVal = SOIL.readSoilSensor(SOIL.SOIL_CHANNEL)
            print("Soil moisture value = %d"%soilVal)
# PSD 
        if text == 'detect position':
            assistant.stop_conversation()
            aiy.audio.say('detect position')
            psdVal = PSD.readPsdSensor(PSD.PSD_CHANNEL)
            print("psd Value = %d "%psdVal)

        if text == 'power off':
            assistant.stop_conversation()
            power_off_pi()
        elif text == 'play music':
            assistant.stop_conversation()
            playMusic()
        elif text == 'reboot':
            assistant.stop_conversation()
            reboot_pi()
        elif text == 'ip address':
            assistant.stop_conversation()
            say_ip()

    elif event.type == EventType.ON_END_OF_UTTERANCE:
        status_ui.status('thinking')

    elif (event.type == EventType.ON_CONVERSATION_TURN_FINISHED
          or event.type == EventType.ON_CONVERSATION_TURN_TIMEOUT
          or event.type == EventType.ON_NO_RESPONSE):
        status_ui.status('ready')

    elif event.type == EventType.ON_ASSISTANT_ERROR and event.args and event.args['is_fatal']:
        sys.exit(1)


def main():
    if platform.machine() == 'armv6l':          # Returns the machine type, e.g. 'i386'.
        print('Cannot run hotword demo on Pi Zero!')
        exit(-1)
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    LED.initLed(LED.LED_1)
    FAN.initFan(FAN.FAN_PIN1, FAN.FAN_PIN2)

    GPIO.setup(BUZZER.BUZZER_PIN, GPIO.OUT)
    pwm = GPIO.PWM(BUZZER.BUZZER_PIN, 100)

    TLCD.initTextlcd()
    FND.initFnd()

#    MOTOR.initMotor()
    GPIO.setup(MOTOR.MOTOR_P_PIN, GPIO.OUT)
    GPIO.setup(MOTOR.MOTOR_N_PIN, GPIO.OUT)
    pwm_p = GPIO.PWM(MOTOR.MOTOR_P_PIN, 100)
    pwm_n = GPIO.PWM(MOTOR.MOTOR_N_PIN, 100)

    SHT.initSHT11()
    ULTRA.initUltrasonic()

    SOIL.initMcp3208()
    CDS.initMcp3208()
    PSD.initMcp3208()

    credentials = aiy.assistant.auth_helpers.get_assistant_credentials()
    with Assistant(credentials) as assistant:
        for event in assistant.start():
            process_event(assistant, event)


if __name__ == '__main__':
    main()

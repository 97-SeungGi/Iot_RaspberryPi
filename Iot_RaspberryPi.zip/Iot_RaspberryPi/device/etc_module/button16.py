import RPi.GPIO as GPIO
from time import sleep

KEYPAD_PB1 =	6
KEYPAD_PB2 =	12
KEYPAD_PB3 =	13
KEYPAD_PB4 =	16
KEYPAD_PB5 =	19
KEYPAD_PB6 =	20
KEYPAD_PB7 =	26
KEYPAD_PB8 =	21

MAX_BUTTON_NUM = 8
#BUTTON_PIN = 4

KeypadTable = [KEYPAD_PB1, KEYPAD_PB2, KEYPAD_PB3, KEYPAD_PB4,
               KEYPAD_PB5, KEYPAD_PB6, KEYPAD_PB7, KEYPAD_PB8]

GPIO.setmode(GPIO.BCM)

def initButton():
    print( "init Button")
    for i in range(0, MAX_BUTTON_NUM):
        GPIO.setup(KeypadTable[i], GPIO.IN)

def readButton():
    print( "read Button")
    buttonPin = 0
    for j in range(0, MAX_BUTTON_NUM):
        if (GPIO.input(KeypadTable[j]) == 0):
            buttonPin |= (1<<j)
    return buttonPin

try:
    initButton()
    while True:
        print( "Button Status : %d"%(readButton()) )
        sleep(1.0)
except KeyboardInterrupt:
    GPIO.cleanup()




'''
import RPi.GPIO as GPIO
from time import sleep

BUTTON_PIN = 17
GPIO.setmode(GPIO.BCM)
print("Setup Button pin as inputs")
#GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(BUTTON_PIN, GPIO.IN)

try:
    while True:
        buttonData = GPIO.input(BUTTON_PIN)
        sleep(0.2)
        print("Button Data : %d"%buttonData)

except KeyboardInterrupt:
    GPIO.cleanup()
'''


import RPi.GPIO as GPIO
from time import sleep

MOTOR_P_PIN = 22
MOTOR_N_PIN = 23

CCW = 1     # count-clockwise
CW = 2      # clockwise

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(MOTOR_P_PIN, GPIO.OUT)
GPIO.setup(MOTOR_N_PIN, GPIO.OUT)
pwm_p = GPIO.PWM(MOTOR_P_PIN, 100)       # frequency = 100 Hz
pwm_n = GPIO.PWM(MOTOR_N_PIN, 100)       # frequency = 100 Hz

def stopMotor():
    pwm_n.stop()
    pwm_p.stop()

def controlMotor(speed, direction):
    pwm_n.start(0)                      # duty cycle = 0
    pwm_p.start(0)                      # duty cycle = 0
    if (direction == CW):
        GPIO.output(MOTOR_N_PIN, GPIO.LOW)
        pwm_p.ChangeDutyCycle(speed)
    elif (direction == CCW):
        GPIO.output(MOTOR_P_PIN, GPIO.LOW)
        pwm_n.ChangeDutyCycle(speed)
def main():
    print("start motor program ...")
    try:
        while True:
           controlMotor(30, CCW)
           sleep(2.0)
           stopMotor()
           sleep(3.0)
           controlMotor(80, CW)
           sleep(2.0)
           stopMotor()
           sleep(5.0)
    except KeyboardInterrupt:
        GPIO.cleanup()
        stopMotor()

if __name__ == '__main__':
    main()

import RPi.GPIO as GPIO
from time import sleep

MAX_FND_POSITION = 6
MAX_FND_LED = 8

FND_SEL0 = 4
FND_SEL1 = 17
FND_SEL2 = 18
FND_SEL3 = 27
FND_SEL4 = 22
FND_SEL5 = 23
fndSelectPinTable = [FND_SEL0, FND_SEL1, FND_SEL2, FND_SEL3, FND_SEL4, FND_SEL5]

FND_DP = 6
FND_A  = 12
FND_B  = 13
FND_C  = 16
FND_D  = 19
FND_E  = 20
FND_F  = 26
FND_G  = 21
fndDataPinTable = [FND_DP, FND_A, FND_B, FND_C, FND_D, FND_E, FND_F, FND_G]

A_BIT = 0x01
B_BIT = 0x02
C_BIT = 0x04
D_BIT = 0x08
E_BIT = 0x10
F_BIT = 0x20
G_BIT = 0x40
DP_BIT= 0x80
fndNumberTable = [
    A_BIT | B_BIT | C_BIT | D_BIT | E_BIT | F_BIT ,        # '0'
    B_BIT | C_BIT ,                                        # '1'
    A_BIT | B_BIT | D_BIT | E_BIT | G_BIT,                 # '2'
    A_BIT | B_BIT | C_BIT | D_BIT | G_BIT,                 # '3'
    B_BIT | C_BIT | F_BIT | G_BIT,                         # '4'
    A_BIT | C_BIT | D_BIT | F_BIT | G_BIT,                 # '5'
    C_BIT | D_BIT | E_BIT | F_BIT | G_BIT,                 # '6'
    A_BIT | B_BIT | C_BIT ,                                # '7'
    A_BIT | B_BIT | C_BIT | D_BIT | E_BIT | F_BIT | G_BIT, # '8'
    A_BIT | B_BIT | C_BIT | F_BIT | G_BIT,                 # '9'
    A_BIT | B_BIT | C_BIT | E_BIT | F_BIT | G_BIT,         # 'A'
    C_BIT | D_BIT | E_BIT | F_BIT | G_BIT,                 # 'b'
    A_BIT | D_BIT | E_BIT | F_BIT,                         # 'C'
    B_BIT | C_BIT | D_BIT | E_BIT | G_BIT,                 # 'd'
    A_BIT | D_BIT | E_BIT | F_BIT | G_BIT,                 # 'E'
    A_BIT | E_BIT | F_BIT | G_BIT,                         # 'F'
]

FND_SEG0 =  0x01
FND_SEG1 =  0x02
FND_SEG2 =  0x04
FND_SEG3 =  0x08
FND_SEG4 =  0x10
FND_SEG5 =  0x20
fndSegmentTable = [FND_SEG0, FND_SEG1, FND_SEG2, FND_SEG3, FND_SEG4, FND_SEG5]

fndText = ['1','2','3','4','5','6','7','8','9','.']

def initFnd():
    for i in range(0, MAX_FND_POSITION):
        GPIO.setup(fndSelectPinTable[i], GPIO.OUT, initial=True)

    for i in range(0, MAX_FND_LED):
        GPIO.setup(fndDataPinTable[i], GPIO.OUT, initial=False)

def selectFnd(position):
    for i in range(0, MAX_FND_POSITION):
        if(position & (1<<i)):
            GPIO.output(fndSelectPinTable[i], GPIO.LOW)
        else:
            GPIO.output(fndSelectPinTable[i], GPIO.HIGH)

def offFnd():
    for i in range(0, MAX_FND_POSITION):
        GPIO.output(fndSelectPinTable[i], GPIO.HIGH)
    for i in range(0, MAX_FND_LED):
        GPIO.output(fndDataPinTable[i], GPIO.LOW)

def fndData(text):
    if(text == '0'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[0] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '1'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[1] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '2'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[2] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '3'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[3] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '4'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[4] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '5'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[5] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '6'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[6] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '7'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[7] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '8'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[8] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '9'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[9] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    if(text == '.'):
        for i in range(0, MAX_FND_LED):
            if(fndNumberTable[10] & (1<<i)):
                GPIO.output(fndDataPinTable[i], GPIO.HIGH)
            else:
                GPIO.output(fndDataPinTable[i], GPIO.LOW)
		sleep(0.001)
    sleep(0.003)

def drawFnd(position, text):
    offFnd()                # By initializing the data, Prevent fndData from changing number.
    selectFnd(position)
    fndData(text)

def main():
    GPIO.setmode(GPIO.BCM)
    initFnd()
    print("Setup 7-Segment pin as outputs")

    print("main() program")
    try:
        while True:
            for i in range(0, MAX_FND_POSITION):
#                print("Seg : %d"%fndSegmentTable[i]),
#                print("Data : %s"%fndText[i])
                drawFnd(fndSegmentTable[i],fndText[i])
#                sleep(0.2)

    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == '__main__':
    main()

import RPi.GPIO as GPIO
from time import sleep

BUTTON_PIN = 17
GPIO.setmode(GPIO.BCM)
print("Setup Button pin as inputs")
GPIO.setup(BUTTON_PIN, GPIO.IN)

try:
    while True:
        buttonData = GPIO.input(BUTTON_PIN)
        sleep(0.2)
        print("Button Data : %d"%buttonData)

except KeyboardInterrupt:
    GPIO.cleanup()



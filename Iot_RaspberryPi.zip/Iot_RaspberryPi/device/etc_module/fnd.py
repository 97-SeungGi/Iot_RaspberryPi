import RPi.GPIO as GPIO
from time import sleep

FND_SEL0 = 4
FND_SEL1 = 17
FND_SEL2 = 18
FND_SEL3 = 27
FND_SEL4 = 22
FND_SEL5 = 23

A_BIT = 0x01
B_BIT = 0x02
C_BIT = 0x04
D_BIT = 0x08
E_BIT = 0x10
F_BIT = 0x20
G_BIT = 0x40
DP_BIT = 0x80

FND_A = 6
FND_B = 12
FND_C = 13
FND_D = 16
FND_E = 19
FND_F = 20
FND_G = 26
FND_DP = 21

MAX_FND_POSITION = 6
MAX_FND_LED = 8

#fndDataTable = [6, 12, 13, 16, 19, 20, 26, 21]
#fndData = [1,0,1,1,0,1,1,0]                         #  "5"

FndSelectTable = [FND_SEL0, FND_SEL1, FND_SEL2, FND_SEL3, FND_SEL4, FND_SEL5]
FndDataTable = [FND_A, FND_B, FND_C, FND_D, FND_E, FND_F, FND_G, FND_DP]

FndNumberTable = [
    A_BIT | B_BIT | C_BIT | D_BIT | E_BIT | F_BIT, 
    B_BIT | C_BIT ,
    A_BIT | B_BIT | D_BIT | E_BIT | G_BIT, 
    A_BIT | B_BIT | C_BIT | D_BIT | G_BIT, 
    B_BIT | C_BIT | F_BIT | G_BIT, 
    A_BIT | C_BIT | D_BIT | F_BIT | G_BIT, 
    C_BIT | D_BIT | E_BIT | F_BIT | G_BIT, 
    A_BIT | B_BIT | C_BIT, 
    A_BIT | B_BIT | C_BIT | D_BIT | E_BIT | F_BIT | G_BIT, 
    A_BIT | B_BIT | C_BIT | F_BIT | G_BIT,
    DP_BIT
]

literalNumberTable = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']


def initFnd():
    GPIO.setwarnings(False)
    for i in range(0, MAX_FND_POSITION):
        GPIO.setup(FndSelectTable[i], GPIO.OUT, initial=True)
    for i in range(0, MAX_FND_LED):
        GPIO.setup(FndDataTable[i], GPIO.OUT, initial=False)

def FndSelect(position):
    for i in range(0, MAX_FND_POSITION):
        if position & (1<<i):
            GPIO.output(FndSelectTable[i], GPIO.LOW)
        else:
            GPIO.output(FndSelectTable[i], GPIO.HIGH)

def FndData(text=""):
    if text == 0:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[0] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 1:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[1] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 2:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[2] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 3:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[3] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
            sleep(0.001)
    if text == 4:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[4] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 5:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[5] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 6:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[6] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 7:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[7] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 8:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[8] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == 9:
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[9] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)
    if text == ".":
        for i in range(0, MAX_FND_LED):
            if FndNumberTable[10] & (1<<i):
                GPIO.output(FndDataTable[i], GPIO.HIGH)
            else:
                GPIO.output(FndDataTable[i], GPIO.LOW)
        sleep(0.001)


def displayFnd(position, text=""):
#    print(position, text)
#    print(type(position), type(text))
    FndSelect(position)
    FndData(text)

def offFnd():
    initFnd()

def displayFnd1():
    GPIO.output(FND_SEL0, GPIO.LOW)                 #  display FND_SEL0
    
    for i in range(0, MAX_FND_LED):
        GPIO.output(FndDataTable[i], FndData[i])


def main():
    GPIO.setmode(GPIO.BCM)
    initFnd()
    print("Setup 7-Segment pin as outputs")

    GPIO.output(FND_SEL0, GPIO.LOW)                 #  display FND_SEL0
    try:
        while True:
            displayFnd(1, 8)
#            displayFnd(1, ".")
            '''            
            for i in range(0, MAX_FND_LED):
                GPIO.output(FndDataTable[i], FndData[i])
            #sleep(0.5)
            '''
    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == '__main__':
    main()

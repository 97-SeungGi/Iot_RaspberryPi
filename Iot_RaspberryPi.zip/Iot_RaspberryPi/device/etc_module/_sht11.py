import RPi.GPIO as GPIO
from time import sleep

SCK	= 3
SDA	= 2

class SHT1xError(Exception):
    pass

class COF():
    D1_VDD_C = {5: -40.1, 4: -39.8, 3.5: -39.7, 3: -39.6, 2.5: -39.4}
    D1_VDD_F = {5: -40.2, 4: -39.6, 3.5: -39.5, 3: -39.3, 2.5: -38.9}
    D2_SO_C = {14: 0.01, 12: 0.04}
    D2_SO_F = {14: 0.018, 12: 0.072}
    C1_SO = {12: -2.0468, 8: -2.0468}
    C2_SO = {12: 0.0367, 8: 0.5872}
    C3_SO = {12: -0.0000015955, 8: -0.00040845}
    T1_SO = {12: 0.01, 8: 0.01}
    T2_SO = {12: 0.00008, 8: 0.00128}

                            # Addr	Code(command)  r/w
MEASURE_TEMP	 =	0x03	# 000       0001  		1
MEASURE_HUMI	 =	0x05	# 000       0010  		1
READ_STATUS_REG	 =	0x07	# 000       0011  		1
WRITE_STATUS_REG =	0x06	# 000       0011  		0
RESET			 =	0x1e   	# 000       1111  		0

Commands = {'Temperature': 0b00000011,
            'Humidity': 0b00000101,
            'ReadStatusRegister': 0b00000111,
            'WriteStatusRegister': 0b00000110,
            'SoftReset': 0b00011110,
            'NoOp': 0b00000000}

bitPos = [0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01]

error = 0
checksum = 0
sensing_type = 0

_command = Commands['NoOp']
ack = GPIO.LOW
temperature_celsius = None
temperature_fahrenheit = None
humidity = None
_status_register = 0b00000000
crc_check = True

def SET_DATA():
    GPIO.output(SDA, GPIO.HIGH)
def CLR_DATA():
    GPIO.output(SDA, GPIO.LOW)
def SET_SCK():
    GPIO.output(SCK, GPIO.HIGH)
def CLR_SCK():
    GPIO.output(SCK, GPIO.LOW)
def READ_DATA():
    return GPIO.input(SDA)
def READ_SCK():
    return GPIO.input(SCK)

def I2C_data_output ():
    GPIO.setup(SDA, GPIO.OUT)
def	I2C_data_input ():
    GPIO.setup(SDA, GPIO.IN)
def I2C_sck_output ():
    GPIO.setup(SCK, GPIO.OUT)

def toggle_pin(pin, state):
    GPIO.output(pin, state)
    if pin == SCK:
        sleep(0.0000001)

def reset_connection ():
    I2C_data_output()
    I2C_sck_output()

    toggle_pin(SDA, GPIO.HIGH)
    for i in range(10):
        toggle_pin(SCK, GPIO.HIGH)
        toggle_pin(SCK, GPIO.LOW)

def read_byte():
    I2C_data_input ()
    I2C_sck_output ()
    data	=	0
    for i in bitPos:
        toggle_pin(SCK, GPIO.HIGH)
        if (READ_DATA()):
#            print(val, i, val | i)
            data = (data | i)
        toggle_pin(SCK, GPIO.LOW)
    return data

def get_byte():
    I2C_data_input ()
    I2C_sck_output ()

    data = 0b00000000
    for i in range(8):
        toggle_pin(SCK, GPIO.HIGH)
        data |= GPIO.input(SDA) << (7 - i)
        toggle_pin(SCK, GPIO.LOW)

    return data

def _send_ack():
    GPIO.setup(SDA, GPIO.OUT)
    GPIO.setup(SCK, GPIO.OUT)

    toggle_pin(SDA, GPIO.HIGH)
    toggle_pin(SDA, GPIO.LOW)
    toggle_pin(SCK, GPIO.HIGH)
    toggle_pin(SCK, GPIO.LOW)

def write_byte (data):
    I2C_data_output()
    I2C_sck_output()
    for i in bitPos:
#        print(i, value, i & value)
        if (i & data):
            toggle_pin(SDA, GPIO.HIGH)
        else:
            toggle_pin(SDA, GPIO.LOW)
        toggle_pin(SCK, GPIO.HIGH)
        toggle_pin(SCK, GPIO.LOW)

def send_byte(data):
    I2C_data_output()
    I2C_sck_output()
    for i in range(8):
        toggle_pin(SDA, data & (1 << 7 - i))
        toggle_pin(SCK, GPIO.HIGH)
        toggle_pin(SCK, GPIO.LOW)

def _get_ack(command_name, _command, ack):
    GPIO.setup(SDA, GPIO.IN)
    GPIO.setup(SCK, GPIO.OUT)

    toggle_pin(SCK, GPIO.HIGH)

    ack = GPIO.input(SDA)
#    print(command_name)
    if ack == GPIO.HIGH:
        message = 'SHT1x failed to properly receive command [{0} - {1:08b}]'.format(command_name, _command)
        raise SHT1xError(message)

    toggle_pin(SCK, GPIO.LOW)

def send_command(_command, ack, measurement=True):
    command_name = [key for key in Commands.keys() if Commands[key] == _command]
#    print(_command)

    transmission_start()
    send_byte(_command)

    _get_ack(command_name, _command, ack)

    if measurement:
        ack = GPIO.input(SDA)

        _wait_for_result()

def _write_status_register(mask, _command):
    _command = Commands['WriteStatusRegister']
#    print(_command)
    send_command(_command, ack, measurement=False)

    send_byte(mask)
    _get_ack('WriteStatusRegister', _command, ack)
    _status_register = mask

def initSHT11 ():
    I2C_data_output ()		# DDRF |= 0x02;
    I2C_sck_output ()		# DDRF |= 0x01;
    reset_connection ()
    mask = 0
    _write_status_register(mask, _command)

def transmission_start ():
    I2C_data_output()
    I2C_sck_output()

    toggle_pin(SDA, GPIO.HIGH)
    toggle_pin(SCK, GPIO.HIGH)
    toggle_pin(SDA, GPIO.LOW)
    toggle_pin(SCK, GPIO.LOW)
    toggle_pin(SCK, GPIO.HIGH)
    toggle_pin(SDA, GPIO.HIGH)
    toggle_pin(SCK, GPIO.LOW)

def transmission_end():
    GPIO.setup(SDA, GPIO.OUT)
    GPIO.setup(SCK, GPIO.OUT)

    toggle_pin(SDA, GPIO.HIGH)
    toggle_pin(SCK, GPIO.HIGH)
    toggle_pin(SCK, GPIO.LOW)

def _wait_for_result():
    GPIO.setup(SDA, GPIO.IN)
    data_ready = GPIO.HIGH

    for i in range(35):
        sleep(.01)
        data_ready = GPIO.input(SDA)
        if data_ready == GPIO.LOW:
            break

def _read_measurement(_command):
    # Get the MSB
    value = get_byte()
    value <<= 8

    _send_ack()

    # Get the LSB
    value |= get_byte()

    _send_ack()

    crc_value = get_byte()

    transmission_end()

    return value

def read_temperature(_command, ack):
    _command = Commands['Temperature']
    send_command(_command, ack)
    raw_temperature = _read_measurement(_command)

    temperature_celsius = round(raw_temperature * COF.D2_SO_C[14] + COF.D1_VDD_C[5], 2)
    temperature_fahrenheit = round(raw_temperature * COF.D2_SO_F[14] + COF.D1_VDD_F[5], 2)

    return temperature_celsius

def read_humidity(_command, ack, temperature=0):
    if temperature is None:
        if temperature_celsius is None:
            read_temperature(_command, ack)
        temperature = temperature_celsius

    _command = Commands['Humidity']
    send_command(_command, ack)
    raw_humidity = _read_measurement(_command)

    linear_humidity = COF.C1_SO[12] + (COF.C2_SO[12] * raw_humidity) + (COF.C3_SO[12] * raw_humidity ** 2)

    humidity = round((temperature - 25) * (COF.T1_SO[12] + COF.T2_SO[12] * raw_humidity) + linear_humidity, 2)

    return humidity

def main():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    initSHT11()
    print('start temperature anc humidity sensor program ...')
    try:
        while True:
            temp = read_temperature(_command, ack)	# Sensing Temp
            humi = read_humidity(_command, ack) 	# Sensing Humi
            sleep(1)

            print("Temp = %2.2f [C], Humi = %2.2f [%%]"%(temp,humi))
    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == '__main__':
    main()

import RPi.GPIO as gpio
import time

TRIG_PIN = 14
ECHO_PIN = 15

def initUltrasonic():
    gpio.setup(TRIG_PIN, gpio.OUT)
    gpio.setup(ECHO_PIN, gpio.IN)

def controlUltrasonic():
    distance = 0.0
    gpio.output(TRIG_PIN, False)
    time.sleep(0.5)
    gpio.output(TRIG_PIN, True)
    time.sleep(0.00001)
    gpio.output(TRIG_PIN, False)

    while gpio.input(ECHO_PIN) == 0 :
        pulse_start = time.time()

    while gpio.input(ECHO_PIN) == 1 :
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17000
    distance = round(distance, 2)

#    print "Distance : ", distance, "cm"
    return distance

def main():
    gpio.setmode(gpio.BCM)
    distance = 0.0
    initUltrasonic()
    print("Ultrasonic Operating ...")

    try:
        while True:
            distance = controlUltrasonic()
            print("Distance : ", distance, "cm")

    except KeyboardInterrupt:
        gpio.cleanup()

if __name__ == '__main__':
    main()

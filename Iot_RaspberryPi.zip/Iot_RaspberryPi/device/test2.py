import RPi.GPIO as GPIO
from time import sleep
import threading

import Adafruit_DHT as DHT

#dht
DHT_PIN = 17
sensor =  DHT.DHT11

def readTemp():
    humidity, temperature = DHT.read_retry(sensor, DHT_PIN)
    if temperature is not None:
        print("Temp=%0.1f[*C]"%temperature)
        return temperature
#        print('Temp={0:0.1f}*C %'.format(temperature) )
    else:
        print('Failed to get reading. Try again!')

def readHumi():
    humidity, temperature = DHT.read_retry(sensor, DHT_PIN)
    if humidity is not None:
        print("Humidity=%0.1f[%%]"%humidity)
        return humidity
#        print('Humidity={1:0.1f}%'.format(humidity))
    else:
        print('Failed to get reading. Try again!')

#fan
ON = 1
OFF = 0
FAN_PIN1 = 18 
FAN_PIN2 = 27

def initFan(fanPin1, fanPin2):
    GPIO.setwarnings(False)
    GPIO.setup(fanPin1, GPIO.OUT, initial=False)
    GPIO.setup(fanPin2, GPIO.OUT, initial=False)

def onFan():
    GPIO.output(FAN_PIN1, GPIO.HIGH)
    GPIO.output(FAN_PIN2, GPIO.LOW)

def offFan():
    GPIO.output(FAN_PIN1, GPIO.LOW)
    GPIO.output(FAN_PIN2, GPIO.LOW)

def controlFan(motion):
    if(motion == ON):
        onFan()
    else:
        offFan()

#pir
PIR_PIN = 5
pirState = 0
ON = 1
OFF = 0

def readPir(detect_state):
    global pirState
    while detect_state:
        input_state = GPIO.input(PIR_PIN)
        if input_state == True:
            if pirState == 0:
                print("Motion Detected.")
            pirState = 1
            return 1
        else:
            if pirState == 1:
                print("Motion Ended.")
            pirState = 0
            return 0


#keypad
COL0_PIN = 6
COL1_PIN = 12
COL2_PIN = 13
ROW0_PIN = 19
ROW1_PIN = 26
ROW2_PIN = 20
ROW3_PIN = 21

COL_NUM = 3
ROW_NUM = 4

colTable = [COL0_PIN, COL1_PIN, COL2_PIN]
rowTable = [ROW0_PIN, ROW1_PIN, ROW2_PIN, ROW3_PIN]

def initKeypad():
    for i in range(0, COL_NUM):
        GPIO.setup(colTable[i], GPIO.IN)
    for i in range(0, ROW_NUM):
        GPIO.setup(rowTable[i], GPIO.OUT, initial=False)

def selectRow(rowNum):
    for i in range(0, ROW_NUM):
        if rowNum == (i+1):
            GPIO.output(rowTable[i], GPIO.HIGH)
#            sleep(0.001)
        else:
            GPIO.output(rowTable[i], GPIO.LOW)
            sleep(0.001)

def readCol():
    keypadstate = -1
    for i in range(0, COL_NUM):
        inputKey = GPIO.input(colTable[i])
        if inputKey:
            keypadstate += (i+2)
#            print("key : %d"%keypadstate)
    return keypadstate


def readKeypad():
#    global keyData
    global g_preData
    keyData = -1
    
    selectRow(1)
    row1Data = readCol()
    if (row1Data != -1):
        keyData = row1Data
        row1Data = -1
#        print("Key1 Data : %d"%keyData)

    if keyData == -1:
        selectRow(2)
        row2Data = readCol()
        if (row2Data != -1):
            keyData = row2Data + 3
            row2Data = -1
#        print("Key2 Data : %d"%keyData)
        
    if keyData == -1:
        selectRow(3)
        row3Data = readCol()
        if (row3Data != -1):
            keyData = row3Data + 6
            row3Data = -1
#        print("Key3 Data : %d"%keyData)
        
    if keyData == -1:
        selectRow(4)
        row4Data = readCol()
        if (row4Data != -1):
            if row4Data == 2:
                keyData = 0
            row4Data = -1
#        print("Key4 Data : %d"%keyData)

#    print("Key Data : %d"%keyData)
#    print("Pre Data : %d"%g_preData)

    if keyData == -1:
        return -1

    print("Keypad Data : %d"%keyData)
    sleep(3)
    return keyData

def keypadTest():
    while True:
        keyData = readKeypad()

def pirTest():
    while True:
        readPir(ON)

def main():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    
    initFan(FAN_PIN1, FAN_PIN2)

    GPIO.setup(PIR_PIN, GPIO.OUT)

    initKeypad()

    print("start test2")


    global t
    t = threading.Thread(target=keypadTest, args=( ))
    t.daemon = True
#    t.start()

    global t1
    t1 = threading.Thread(target=pirTest, args=( ))
    t1.daemon = True
    t1.start()

    controlFan(ON)
    sleep(3.0)
    controlFan(OFF)

    try:
        while True:
            readTemp()
            sleep(0.5)
            readHumi()
            sleep(0.5)

    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == '__main__':
    main()

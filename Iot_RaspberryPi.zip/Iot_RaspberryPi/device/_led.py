import RPi.GPIO as GPIO
from time import sleep

ON = 1
OFF = 0

LED_1 = 4
LED_2 = 5
LED_3 = 14
LED_4 = 15

LED_PIN1 = 4
LED_PIN2 = 5
LED_PIN3 = 14
LED_PIN4 = 15
#LED_PIN5 = 22
#LED_PIN6 = 23
#LED_PIN7 = 24
#LED_PIN8 = 25
MAX_LED_NUM = 4

#LedTable = [LED_PIN1, LED_PIN2, LED_PIN3, LED_PIN4, LED_PIN5, LED_PIN6, LED_PIN7, LED_PIN8]
LedTable = [LED_PIN1, LED_PIN2, LED_PIN3, LED_PIN4]

def initLed(ledNum):
    GPIO.setup(ledNum, GPIO.OUT, initial=False)
    GPIO.setwarnings(False)

def initLedModule():
    for i in range(0, MAX_LED_NUM):
        GPIO.setwarnings(False)
        GPIO.setup(LedTable[i], GPIO.OUT, initial=False)

def controlLed(ledNum, ledStat):
    if(ledStat == ON):
        GPIO.output(ledNum, GPIO.HIGH)
    else:
        GPIO.output(ledNum, GPIO.LOW)

def controlLedModule(ledPos):
    '''
    :param ledPos: 0x01 ~ 0xff
    :return:
    '''
    for i in range(0, MAX_LED_NUM):
        if(ledPos & (1<<i)):
            GPIO.output(LedTable[i], GPIO.HIGH)
#            print('LED %d HIGH'%LedTable[i])
        else:
            GPIO.output(LedTable[i], GPIO.LOW)
#            print('LED %d HIGH'%LedTable[i])

def main():
    GPIO.setmode(GPIO.BCM)
    initLedModule()
    print("Setup LED pin as outputs")

    print("main() program")
    try:
        while True:
            controlLedModule(0x01)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x02)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x04)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x08)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)

    except KeyboardInterrupt:
        GPIO.cleanup()

if __name__ == '__main__':
    main()

'''
    try:
        while True:
            GPIO.output(LED_PIN, True)
            sleep(0.5)
            GPIO.output(LED_PIN, False)
            sleep(0.5)

    except KeyboardInterrupt:
        GPIO.cleanup()
'''

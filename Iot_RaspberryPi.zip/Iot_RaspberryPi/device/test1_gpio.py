import RPi.GPIO as GPIO
from time import sleep

try:
    import aiy.device.Adafruit.CharLCD as LCD
except ImportError:
    import Adafruit_CharLCD as LCD

#led
ON = 1
OFF = 0

LED_1 = 4
LED_2 = 17
LED_3 = 18
LED_4 = 27

MAX_LED_NUM = 4

LedTable = [LED_1, LED_2, LED_3, LED_4]

def initLedModule():
    for i in range(0, MAX_LED_NUM):
        GPIO.setwarnings(False)
        GPIO.setup(LedTable[i], GPIO.OUT, initial=False)
        
def controlLedModule(ledPos):
    '''
    :param ledPos: 0x01 ~ 0xff
    :return:
    '''
    for i in range(0, MAX_LED_NUM):
        if(ledPos & (1<<i)):
            GPIO.output(LedTable[i], GPIO.HIGH)
#            print('LED %d HIGH'%LedTable[i])
        else:
            GPIO.output(LedTable[i], GPIO.LOW)
#            print('LED %d HIGH'%LedTable[i])


#buzzer
BUZZER_PIN  = 7

scale = [ 261, 294, 329, 349, 392, 440, 493, 523 ]

#melodySize = 24;
melodyList = [4, 4, 5, 5, 4, 4, 2, 4, 4, 2, 2, 1]
noteDurations = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0.5, 0.5, 0.5, 0.5, 1]

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(BUZZER_PIN, GPIO.OUT)
pwm = GPIO.PWM(BUZZER_PIN, 100)       # frequency = 100 Hz

def playBuzzer(melodyList, noteDurations):
    pwm.start(100)                        # duty cycle = 100
    pwm.ChangeDutyCycle(50)
#    pwm.ChangeDutyCycle(90)
    for i in range(len(melodyList)):
        pwm.ChangeFrequency(scale[melodyList[i]])
        sleep(noteDurations[i])
    pwm.stop()

#adc
import spidev

spi = spidev.SpiDev()
CDS_CHANNEL = 0
GAS_CHANNEL = 1

def initMcp3208():
    spi.open(0,0)                   # open(bus,device), device 0 - CE0(GPIO8), device 1 - CE1(GPIO7)
    spi.max_speed_hz = 1000000      # set 1MHz
    spi.mode = 3                    # set 0b11

def buildReadCommand(channel):
    '''
    # Return python list of 3 bytes
    #   Build a python list using [1, 2, 3]
    #   First byte is the start bit
    #   Second byte contains single ended along with channel #
    #   3rd byte is 0
    '''
    startBit = 0x01
    singleEnded = 0x08
    return [startBit, singleEnded|(channel<<4), 0]

def processAdcValue(result):
    '''Take in result as array of three bytes.
       Return the two lowest bits of the 2nd byte and
       all of the third byte'''
    byte2 = (result[1] & 0x03)
    return (byte2 << 8) | result[2]

def analogRead(channel):
    if ((channel>7) or (channel<0)):
        return -1
#    r = spi.xfer2([1, (8 + channel) << 4, 0])
    r = spi.xfer2(buildReadCommand(channel))
#    adc_out = ((r[1]&3) << 8) + r[2]
    adc_out = processAdcValue(r)
    return adc_out

def controlMcp3208(channel):
    analogVal = analogRead(channel)
#    print("gas = %d "%analogVal)
    return analogVal

def readSensor(channel):
    return controlMcp3208(channel)


#textlcd
LCD_RS = 22
#LCD_RW = GND(23)
LCD_RW = 23
LCD_E = 24
LCD_D4 = 19
LCD_D5 = 20
LCD_D6 = 26
LCD_D7 = 21

# Define LCD column and row size for 16x2 LCD.
lcd_columns = 16
lcd_rows = 2

lcd = LCD.Adafruit_CharLCD(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7, lcd_columns, lcd_rows)

def initTextlcd():
    GPIO.setup(LCD_RW, GPIO.OUT, initial=False)
    lcd.clear()
    lcd.home()
    lcd.show_cursor(True)
    lcd.blink(True)
#    lcd.message('Hello\nworld!')
    sleep(1.0)      # Wait 1 seconds

def displayText(text=''):
    lcd.clear()
    lcd.set_cursor(0, 0)
    lcd.message(text[:16])
    lcd.set_cursor(0, 1)
    lcd.message(text[16:])

def controlTextlcd(column, line):
    text = raw_input("Type Something to be displayed on the 1st line: ")
    lcd.clear()
    lcd.set_cursor(column, line)
    lcd.message(text)
    text = raw_input("Type Something to be displayed on the 2nd line: ")
    lcd.set_cursor(column, line+1)
    lcd.message(text)

#    lcd.move_right()    # move entire display
#    sleep(2.0)
#    lcd.move_left()
#    sleep(2.0)

def clearTextlcd():
    lcd.clear()
    lcd.message('clear LCD\nGoodbye!')
#    lcd.message('Goodbye\nWorld!')
    sleep(2.0)
    lcd.clear()
    lcd.show_cursor(False)
    lcd.blink(False)

def main():
#    GPIO.setmode(GPIO.BCM)
    initLedModule()
    initTextlcd()
    initMcp3208()


    print("start test program ...")

    try:
        while True:
	    controlLedModule(0x01)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x02)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x04)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x08)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            
            playBuzzer(melodyList, noteDurations)
            pwm.stop()
            
            readVal = readSensor(GAS_CHANNEL)
            voltage = readVal * 3.3 / 1024
            print("GAS Val=%d\tVoltage=%f" % (readVal, voltage))
            sleep(0.5)
            readVal = readSensor(CDS_CHANNEL)
            voltage = readVal * 3.3 / 1024
            print("CDS Val=%d\tVoltage=%f" % (readVal, voltage))
            sleep(0.5)

            controlTextlcd(0, 0)
#            displayText('start LCD')
            sleep(0.5)

    except KeyboardInterrupt:
        clearTextlcd()
 #       GPIO.cleanup()


if __name__ == '__main__':
    main()

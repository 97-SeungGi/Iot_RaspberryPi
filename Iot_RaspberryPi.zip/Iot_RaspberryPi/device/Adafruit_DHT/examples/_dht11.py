import RPi.GPIO as GPIO
#import aiy.device.Adafruit_DHT as DHT
import Adafruit_DHT as DHT
from time import sleep

# Raspberry Pi pin setup
DHT11 = 17

sensor =  DHT.DHT11

humidity, temperature = DHT.read_retry(sensor, DHT11)

def readTemp():
    humidity, temperature = DHT.read_retry(sensor, DHT11)
    if humidity is not None and temperature is not None:
        print('Temp={0:0.1f}*C Humidity={1:0.1f}%'.format(temperature, humidity))
    else:
        print('Failed to get reading. Try again!')

def readHumi():
    humidity = DHT.read_retry(sensor, DHT11)
    if humidity is not None:
        print('Humidity={1:0.1f}%'.format(humidity))
    else:
        print('Failed to get reading. Try again!')

def main():
#    GPIO.setmode(GPIO.BCM)
#    initDht11()
    print("start dht11 program ...")

    try:
        while True:
            readTemp()
            sleep(0.5)
            
    except KeyboardInterrupt:
       GPIO.cleanup()

if __name__ == '__main__':
    main()

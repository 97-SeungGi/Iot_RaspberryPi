import RPi.GPIO as GPIO
import Adafruit_DHT as DHT
from time import sleep

# Raspberry Pi pin setup
DHT_PIN = 17

sensor =  DHT.DHT11
#humidity, temperature = DHT.read_retry(sensor, DHT_PIN)

def readTemp():
    humidity, temperature = DHT.read_retry(sensor, DHT_PIN)
    if temperature is not None:
        print("Temp=%0.1f[*C]"%temperature)
        return temperature
#        print('Temp={0:0.1f}*C %'.format(temperature) )
    else:
        print('Failed to get reading. Try again!')

def readHumi():
    humidity, temperature = DHT.read_retry(sensor, DHT_PIN)
    if humidity is not None:
        print("Humidity=%0.1f[%%]"%humidity)
        return humidity
#        print('Humidity={1:0.1f}%'.format(humidity))
    else:
        print('Failed to get reading. Try again!')

def main():
#    GPIO.setmode(GPIO.BCM)
#    initDht11()
    print("start dht11 program ...")

    try:
        while True:
            readTemp()
            sleep(0.5)
            readHumi()
            sleep(0.5)
            
    except KeyboardInterrupt:
       GPIO.cleanup()

if __name__ == '__main__':
    main()

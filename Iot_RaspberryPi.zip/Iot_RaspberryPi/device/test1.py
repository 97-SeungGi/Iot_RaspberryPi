import RPi.GPIO as GPIO
from time import sleep
import GPIO_EX
import threading


try:
    import aiy.device.Adafruit.CharLCD as LCD
except ImportError:
    import Adafruit_CharLCD as LCD

#led
ON = 1
OFF = 0

LED_1 = 4
LED_2 = 5
LED_3 = 14
LED_4 = 15

MAX_LED_NUM = 4

LedTable = [LED_1, LED_2, LED_3, LED_4]

def initLedModule():
    for i in range(0, MAX_LED_NUM):
        GPIO.setwarnings(False)
        GPIO.setup(LedTable[i], GPIO.OUT, initial=False)
        
def controlLedModule(ledPos):
    '''
    :param ledPos: 0x01 ~ 0xff
    :return:
    '''
    for i in range(0, MAX_LED_NUM):
        if(ledPos & (1<<i)):
            GPIO.output(LedTable[i], GPIO.HIGH)
#            print('LED %d HIGH'%LedTable[i])
        else:
            GPIO.output(LedTable[i], GPIO.LOW)
#            print('LED %d HIGH'%LedTable[i])


#buzzer
BUZZER_PIN  = 7

scale = [ 261, 294, 329, 349, 392, 440, 493, 523 ]

#melodySize = 24;
melodyList = [4, 4, 5, 5, 4, 4, 2, 4, 4, 2, 2, 1]
noteDurations = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1, 0.5, 0.5, 0.5, 0.5, 1]

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(BUZZER_PIN, GPIO.OUT)
pwm = GPIO.PWM(BUZZER_PIN, 100)       # frequency = 100 Hz

def playBuzzer(melodyList, noteDurations):
    pwm.start(100)                        # duty cycle = 100
    pwm.ChangeDutyCycle(50)
#    pwm.ChangeDutyCycle(90)
    for i in range(len(melodyList)):
        pwm.ChangeFrequency(scale[melodyList[i]])
        sleep(noteDurations[i])
    pwm.stop()

#adc
import spidev

spi = spidev.SpiDev()
CDS_CHANNEL = 0
GAS_CHANNEL = 1

def initMcp3208():
    spi.open(0,0)                   # open(bus,device), device 0 - CE0(GPIO8), device 1 - CE1(GPIO7)
    spi.max_speed_hz = 1000000      # set 1MHz
    spi.mode = 3                    # set 0b11

def buildReadCommand(channel):
    '''
    # Return python list of 3 bytes
    #   Build a python list using [1, 2, 3]
    #   First byte is the start bit
    #   Second byte contains single ended along with channel #
    #   3rd byte is 0
    '''
    startBit = 0x04
    singleEnded = 0x08
    configBit = [startBit|((singleEnded|(channel&0x07))>>2), (channel&0x07)<<6, 0x00]
    return configBit

def processAdcValue(result):
    '''Take in result as array of three bytes.
       Return the two lowest bits of the 2nd byte and
       all of the third byte'''
    byte2 = (result[1] & 0x0f)
    return (byte2 << 8) | result[2]

def analogRead(channel):
    if ((channel>7) or (channel<0)):
        return -1
#    r = spi.xfer2([1, (8 + channel) << 4, 0])
    r = spi.xfer2(buildReadCommand(channel))
#    adc_out = ((r[1]&3) << 8) + r[2]
    adc_out = processAdcValue(r)
    return adc_out

def controlMcp3208(channel):
    analogVal = analogRead(channel)
#    print("gas = %d "%analogVal)
    return analogVal

def readSensor(channel):
    return controlMcp3208(channel)


#textlcd
LCD_RS = 22
#LCD_RW = GND(23)
LCD_RW = 23
LCD_E = 24
LCD_D4 = 19
LCD_D5 = 20
LCD_D6 = 26
LCD_D7 = 21

# Define LCD column and row size for 16x2 LCD.
lcd_columns = 16
lcd_rows = 2

lcd = LCD.Adafruit_CharLCD(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7, lcd_columns, lcd_rows)

def initTextlcd():
    GPIO.setup(LCD_RW, GPIO.OUT, initial=False)
    lcd.clear()
    lcd.home()
    lcd.show_cursor(True)
    lcd.blink(True)
#    lcd.message('Hello\nworld!')
    sleep(1.0)      # Wait 1 seconds

def displayText(text=''):
    lcd.clear()
    lcd.set_cursor(0, 0)
    lcd.message(text[:16])
    lcd.set_cursor(0, 1)
    lcd.message(text[16:])

def controlTextlcd(column, line):
    text = raw_input("Type Something to be displayed on the 1st line: ")
    lcd.clear()
    lcd.set_cursor(column, line)
    lcd.message(text)
    text = raw_input("Type Something to be displayed on the 2nd line: ")
    lcd.set_cursor(column, line+1)
    lcd.message(text)

#    lcd.move_right()    # move entire display
#    sleep(2.0)
#    lcd.move_left()
#    sleep(2.0)

def clearTextlcd():
    lcd.clear()
    lcd.message('clear LCD\nGoodbye!')
#    lcd.message('Goodbye\nWorld!')
    sleep(2.0)
    lcd.clear()
    lcd.show_cursor(False)
    lcd.blink(False)


ROW0_PIN = 0
ROW1_PIN = 1
ROW2_PIN = 2
ROW3_PIN = 3
COL0_PIN = 4
COL1_PIN = 5
COL2_PIN = 6

COL_NUM = 3
ROW_NUM = 4

colTable = [COL0_PIN, COL1_PIN, COL2_PIN]
rowTable = [ROW0_PIN, ROW1_PIN, ROW2_PIN, ROW3_PIN]

g_preData = 0
g_counter = 0

def initKeypad():
    for i in range(0, COL_NUM):
        GPIO_EX.setup(colTable[i], GPIO_EX.IN)
    for i in range(0, ROW_NUM):
        GPIO_EX.setup(rowTable[i], GPIO_EX.OUT)

def selectRow(rowNum):
    for i in range(0, ROW_NUM):
        if rowNum == (i+1):
            GPIO_EX.output(rowTable[i], GPIO_EX.HIGH)
        else:
            GPIO_EX.output(rowTable[i], GPIO_EX.LOW)

def readCol():
    keypadstate = -1
    for i in range(0, COL_NUM):
        inputKey = GPIO_EX.input(colTable[i])
        if inputKey:
            keypadstate += (i+2)
    return keypadstate

def inputText(keyData):
    global g_counter
    if keyData == 0:
        inputPasswd.append('0')
        g_counter += 1
    elif keyData == 1:
        inputPasswd.append('1')
        g_counter += 1
    elif keyData == 2:
        inputPasswd.append('2')
        g_counter += 1
    elif keyData == 3:
        inputPasswd.append('3')
        g_counter += 1
    elif keyData == 4:
        inputPasswd.append('4')
        g_counter += 1
    elif keyData == 5:
        inputPasswd.append('5')
        g_counter += 1
    elif keyData == 6:
        inputPasswd.append('6')
        g_counter += 1
    elif keyData == 7:
        inputPasswd.append('7')
        g_counter += 1
    elif keyData == 8:
        inputPasswd.append('8')
        g_counter += 1
    elif keyData == 9:
        inputPasswd.append('9')
        g_counter += 1

def readKeypad():
    global g_preData
    keyData = -1

    selectRow(1)
    row1Data = readCol()
    if (row1Data != -1):
        keyData = row1Data

    if keyData == -1:
        selectRow(2)
        row2Data = readCol()
        if (row2Data != -1):
            keyData = row2Data +3
            row2Data = -1

    if keyData == -1:
        selectRow(3)
        row3Data = readCol()
        if (row3Data != -1):
            keyData = row3Data +6
            row3Data = -1

    if keyData == -1:
        selectRow(4)
        row4Data = readCol()
        if (row4Data != -1):
            if row4Data == 2:
                keyData = 0
            row4Data = -1

    if keyData == -1:
        return -1

    print("Keypad Data : %d"%keyData)
    sleep(0.5)
    return keyData

def threadKeypad():
    while True:
        readKeypad()

def main():
#    GPIO.setmode(GPIO.BCM)
    initLedModule()
    initTextlcd()
    initMcp3208()
    initKeypad()

    t = threading.Thread(target=threadKeypad, args=( ))
    t.daemon = True
    t.start()


    print("start test program ...")

    try:
        while True:
	    controlLedModule(0x01)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x02)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x04)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            controlLedModule(0x08)
            sleep(0.5)
            controlLedModule(0x00)
            sleep(0.5)
            
            playBuzzer(melodyList, noteDurations)
            pwm.stop()
            
            readVal = readSensor(GAS_CHANNEL)
            voltage = readVal * 4.096 / 4096
            print("GAS Val=%d\tVoltage=%f" % (readVal, voltage))
            sleep(0.5)
            readVal = readSensor(CDS_CHANNEL)
            voltage = readVal * 4.096 / 4096
            print("CDS Val=%d\tVoltage=%f" % (readVal, voltage))
            sleep(0.5)

            controlTextlcd(0, 0)
#            displayText('start LCD')
            sleep(0.5)

    except KeyboardInterrupt:
        clearTextlcd()
 #       GPIO.cleanup()


if __name__ == '__main__':
    main()
